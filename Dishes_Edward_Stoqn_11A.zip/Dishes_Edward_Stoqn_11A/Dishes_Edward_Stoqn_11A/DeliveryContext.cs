﻿using System;
using Dishes_Edward_Stoqn_11A.Models;
using System.Data.Entity;

namespace Dishes_Edward_Stoqn_11A
{
    public class DeliveryContext : DbContext
    {
        public DeliveryContext() : base("name=Delivery")
        {
        }
        public DbSet<Dishes> Dishes { get; set; }
        public DbSet<DishType> DishTypes { get; set; }
    }
}
