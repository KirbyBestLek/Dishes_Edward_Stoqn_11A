﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace Dishes_Edward_Stoqn_11A
{
    public partial class Form1 : Form
    {
        private string connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Delivery;Integrated Security=true";
        private int selectedDishId = -1;

        public Form1()
        {
            InitializeComponent();
            listBox1.SelectedIndexChanged += ListBox1_SelectedIndexChanged;
        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                string selectedItem = listBox1.SelectedItem.ToString();
                string[] parts = selectedItem.Split('|');
                string idPart = parts[0].Trim();

                if (int.TryParse(idPart, out int id))
                {
                    selectedDishId = id;
                }
                else
                {
                    selectedDishId = -1;
                }
            }
            else
            {
                selectedDishId = -1;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    SqlDataAdapter dishesAdapter = new SqlDataAdapter(@"SELECT d.*, dt.name AS DishTypeName FROM Dishes d JOIN DishTypes dt ON d.DishTypeId = dt.id", conn);
                    DataTable dishesTable = new DataTable();
                    dishesAdapter.Fill(dishesTable);

                    listBox1.Items.Clear();

                    foreach (DataRow row in dishesTable.Rows)
                    {
                        string item = "";
                        for (int i = 0; i < dishesTable.Columns.Count; i++)
                        {
                            if (dishesTable.Columns[i].ColumnName != "DishTypeId")
                            {
                                item += row[i].ToString() + " | ";
                            }
                        }
                        item = item.TrimEnd(' ', '|');
                        listBox1.Items.Add(item);
                    }

                    SqlDataAdapter dishTypesAdapter = new SqlDataAdapter("SELECT id, name FROM DishTypes", conn);
                    DataTable dishTypesTable = new DataTable();
                    dishTypesAdapter.Fill(dishTypesTable);

                    comboBox1.DisplayMember = "name";
                    comboBox1.ValueMember = "id";
                    comboBox1.DataSource = dishTypesTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Проблем с базата данни: " + ex.Message);
                }
            }
        }

        private void addbtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text) || string.IsNullOrWhiteSpace(textBox3.Text) || string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Всички полета трябва да са запълнени");
                return;
            }

            if (!double.TryParse(textBox3.Text, out double dishPrice) || !double.TryParse(textBox4.Text, out double dishWeight))
            {
                MessageBox.Show("Цената и грамажа трябва да са числа");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string dishName = textBox1.Text;
                    string dishDescription = textBox2.Text;
                    int selectedDishTypeId = (int)comboBox1.SelectedValue;

                    string insertQuery = "INSERT INTO Dishes (Name, Description, Price, Weight, DishTypeId) VALUES (@Name, @Description, @Price, @Weight, @DishTypeId)";
                    using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", dishName);
                        cmd.Parameters.AddWithValue("@Description", dishDescription);
                        cmd.Parameters.AddWithValue("@Price", dishPrice);
                        cmd.Parameters.AddWithValue("@Weight", dishWeight);
                        cmd.Parameters.AddWithValue("@DishTypeId", selectedDishTypeId);

                        cmd.ExecuteNonQuery();
                    }

                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    comboBox1.SelectedIndex = 0;

                    Form1_Load(sender, e);

                    MessageBox.Show("Ястието е добавено!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Проблем с базата данни: " + ex.Message);
                }
            }
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            if (selectedDishId == -1)
            {
                MessageBox.Show("Избери ястие за обновяване");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string selectedItem = listBox1.SelectedItem.ToString();
                    string[] parts = selectedItem.Split('|');

                    string oldName = parts[1].Trim();
                    string oldDescription = parts[2].Trim();
                    double oldPrice = double.Parse(parts[3].Trim());
                    double oldWeight = double.Parse(parts[4].Trim());

                    string dishName = string.IsNullOrWhiteSpace(textBox1.Text) ? oldName : textBox1.Text;
                    string dishDescription = string.IsNullOrWhiteSpace(textBox2.Text) ? oldDescription : textBox2.Text;

                    double dishPriceInput = oldPrice;
                    if (!string.IsNullOrWhiteSpace(textBox3.Text))
                    {
                        if (!double.TryParse(textBox3.Text, out dishPriceInput))
                        {
                            MessageBox.Show("Цената трябва да е число");
                            return;
                        }
                    }

                    double dishWeightInput = oldWeight;
                    if (!string.IsNullOrWhiteSpace(textBox4.Text))
                    {
                        if (!double.TryParse(textBox4.Text, out dishWeightInput))
                        {
                            MessageBox.Show("Грамажа трябва да е число");
                            return;
                        }
                    }
                    int selectedDishTypeId = (int)comboBox1.SelectedValue;

                    string updateQuery = "UPDATE Dishes SET Name = @Name, Description = @Description, Price = @Price, Weight = @Weight, DishTypeId = @DishTypeId WHERE Id = @Id";
                    using (SqlCommand cmd = new SqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", dishName);
                        cmd.Parameters.AddWithValue("@Description", dishDescription);
                        cmd.Parameters.AddWithValue("@Price", dishPriceInput);
                        cmd.Parameters.AddWithValue("@Weight", dishWeightInput);
                        cmd.Parameters.AddWithValue("@DishTypeId", selectedDishTypeId);
                        cmd.Parameters.AddWithValue("@Id", selectedDishId);

                        cmd.ExecuteNonQuery();
                    }

                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    selectedDishId = -1;

                    Form1_Load(sender, e);

                    MessageBox.Show("Ястието е обновено!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Проблем с базата данни: " + ex.Message);
                }
            }
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (selectedDishId == -1)
            {
                MessageBox.Show("Избери ястие за изтриване");
                return;
            }

            DialogResult result = MessageBox.Show("Сигурен ли си за изтриването?", "Изтриване на ястие", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    try
                    {
                        conn.Open();

                        string deleteQuery = "DELETE FROM Dishes WHERE Id = @Id";
                        using (SqlCommand cmd = new SqlCommand(deleteQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@Id", selectedDishId);
                            cmd.ExecuteNonQuery();
                        }

                        Form1_Load(sender, e);
                        selectedDishId = -1;

                        MessageBox.Show("Ястието е изтрито!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Проблем с базата данни: " + ex.Message);
                    }
                }
            }
        }
    }
}