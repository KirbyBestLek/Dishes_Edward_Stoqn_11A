﻿using System;
using System.Collections.Generic;

namespace Dishes_Edward_Stoqn_11A.Models
{
    public class DishType
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public ICollection<Dishes> Dishes { get; set; }
        public override string ToString()
        {
            return Name;
        }
    }
}