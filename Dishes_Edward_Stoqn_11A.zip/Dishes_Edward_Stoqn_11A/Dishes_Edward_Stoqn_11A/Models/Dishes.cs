﻿using System;

namespace Dishes_Edward_Stoqn_11A.Models
{
    public class Dishes
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public double Weight { get; set; }
        public int DishTypeId { get; set; }
        public Dishes Dish { get; set; }
        public override string ToString()
        {
            return Name;
        }
    }
}